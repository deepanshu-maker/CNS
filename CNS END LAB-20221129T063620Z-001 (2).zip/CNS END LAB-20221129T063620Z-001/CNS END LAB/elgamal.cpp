#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int fastExponentiation(int a,int b,int n){
    string b_bits="";
    while(b){
        b_bits += (to_string(b%2));
        b/=2;

    }
    reverse(b_bits.begin(),b_bits.end());
    int f=1;

    for(int i=0;i<b_bits.length();i++){
            f=(f*f)%n;
            if(b_bits[i]=='1'){
                f=(f*a)%n;
            }
    }
    return f;
}
int main(){
    int q,alpha;
    cout<<"Enter a prime no and its primitive root\n";
    cin>>q>>alpha;

    // key generation(alice)
    srand(time(0));
    int XA = rand() % (q-1);
    int YA = fastExponentiation(alpha,XA,q);

  // Encryption (Bob)
    int M;
    cout<<"enter the msg\n";
    cin>>M;
    int R =rand() %q;

    int C1 = fastExponentiation(alpha,R,q);
    int temp =fastExponentiation(YA,R,q);
    int C2 = (M * temp) % q;
    cout<< "Cipher text: (C1,C2): "<<C1<<" "<<C2<<"\n";

    // Decryption(Alicw)

    int temp2 = fastExponentiation(C1, XA, q);
    int inv;
    for(int i=1;i<q;i++){
        if((i*temp2)%q == 1)
        {
            inv=i;break;
        }

    }
    cout<<"Decrypted msg is: "<< (C2*inv)%q<<"\n";
    
}