#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int fastExponentiation(int a, int b, int n){
    /// return (a^b)mod n
    string b_bits="";
    while(b){
        b_bits+=(to_string(b%2));
        b/=2;
    }
    reverse(b_bits.begin(),b_bits.end());
    int f=1;
    for(int i=0;i<b_bits.length();i++){
        f=(f*f)%n;
        if(b_bits[i]=='1'){
            f=(f*a)%n;
        }
    }
    return f;
}
int main(){
    int p,q;
    cout<<"Enter te two prime numbers:\n";
    cin>>p>>q;
    int n;
    n=p*q;
    
    int phi_n;
    phi_n=(p-1)*(q-1);

    int e;
    for(int i=2;i<phi_n;i++){
        if(__gcd(i,phi_n)==1)
        {
            e=i;break;
        }
    }
    int d;
    for(int i=1;i<phi_n;i++){
        if((e*i)%phi_n==1){
            d=i;break;
        }
    }

    cout<<"Public Key e: "<<e<<"\nPrivate Key d: "<<d<<"\n";
    int M;
    cout<<"Enter the Message\n";
    cin>>M;

    // Encryption
    int C=fastExponentiation(M,e,n);
    cout<<"Cipher Text: "<<C<<"\n";

    // Decryption
    int decryptedText = fastExponentiation(C,d,n);
    cout<<"Decrypted Text: "<<decryptedText<<"\n";

}