#include <algorithm>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdint>

using namespace std;

int main() {
    {
        ofstream out("tekst.txt");
        out << "Plaintext";
    }

    unsigned char S[256];

    int i = 0;
    for (i = 0; i < 256; i++)
        S[i] = i;

    string Key;
    cout << "Enter the key: ";
    cin >> Key;

    int j = 0;
    for (i = 0; i < 256; i++) {
        j = (j + S[i] + Key.at(i % Key.length())) % 256;
        swap(S[i], S[j]);
    }

    ifstream plik;
    string path = "tekst.txt";
    plik.open(path);

    string printFile = "Encryption_" + path;
    ofstream outfile(printFile);

    char x;
    j = 0;
    i = 0;
    char temp = 0;
    while (plik.read(&x, 1)) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        swap(S[i], S[j]);
        temp = S[(S[i] + S[j]) % 256] ^ x;
        outfile << temp;
        cout << std::hex << std::setw(2) << std::setfill('0')
             << uint32_t(uint8_t(temp)) << " ";
    }

    plik.close();
    outfile.close();

    return 0;
}