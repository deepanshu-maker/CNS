#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int fastExponentiation(int a,int b,int n){
    string b_bits="";
    while(b){
        b_bits += (to_string(b%2));
        b/=2;

    }
    reverse(b_bits.begin(),b_bits.end());
    int f=1;

    for(int i=0;i<b_bits.length();i++){
            f=(f*f)%n;
            if(b_bits[i]=='1'){
                f=(f*a)%n;
            }
    }
    return f;
}
int main(){
    int q,alpha;
    cout<<"Enter the prime no and its primitive root\n";
    cin>>q>>alpha;

    srand(time(0));
    
    // Alice side;

    int XA = rand() % q;
    cout<<"PRivate key of alice: "<<XA<<"\n";
    int YA = fastExponentiation(alpha,XA,q);

    // Bob side

    int XB= rand() %q;
    cout<<"Pricate key of bob: "<<XB<<"\n";
    int YB = fastExponentiation(alpha,XB,q);

    // Key Generation
    int KA = fastExponentiation(YB,XA,q);
    int KB = fastExponentiation(YA,XB,q);


    if(KA == KB)
    cout<<"BOTh generated same secret key: "<<KA<<"\n";
    else
    cout<<"Diff key genrated by both\n";
}