#include<iostream>
using namespace std;
int main(){
    cout<<"Enter the plain text\n";
    string pt;
    getline(cin,pt);
    // cout<<(pt);
    int j=0;
    string cipher="";
    for(int i=0;i<pt.length();i++){
        if(pt[i]==' ')
        continue;
        cipher+= char (((pt[i]-'a')+3)%26)+'a';
    }
    cout<<"Cipher text: "<<cipher<<"\n";
     
}