#include<bits/stdc++.h>
using namespace std;
int main()
{
  int n,m;
  cout<<"Enter the number of rows in key";
  cin>>n;
  cout<<"Enter the number of columns in key";
  cin>>m;
 
  int key[n][m];
  cout<<"Enter the keys\n";
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<m;j++)
    {
    	int x;
    	cin>>x;
    	key[i][j]=x;
    }
  }
  string data;
  cout<<"Enter data"<<endl;
  cin>>data;
  float dl=data.length();
  int datalen=ceil(dl/m);
  int d[m][datalen];
  int itr=0;
  
  for(int j=0;j<datalen;j++)
  {
     for(int i=0;i<m;i++)
     {
     	if(itr<data.length())
     	{
     	     d[i][j]=(data[itr++]-'a');
     	}
     	else
     	{
     	     d[i][j]=(itr%26);
     	     itr++;
     	}
     }
  }
  int c[n][datalen];
  for(int i=0;i<n;i++)
  {
     for(int j=0;j<datalen;j++)
     {
     	int s=0;
     	for(int k=0;k<m;k++)
     	{
     	   s+=key[i][k]*d[k][j];
     	}
     	s%=26;
     	c[i][j]=s;
     }
  }
  string ciphertext;
  for(int j=0;j<datalen;j++)
  {
    for(int i=0;i<m;i++)
    {
    	ciphertext.push_back(c[i][j]+'a');
    }
  }
  
  cout<<"ciphertext :- "<<ciphertext<<endl;

  
  
}