#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
    string pt;
    cin>>pt;
    string key;
    cin>>key;
    int row,col;
    cin>>row>>col;
    int k=0;
    vector<vector<char> > ptMatrix(row,vector<char>(col));
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            if(k==pt.length()){
                ptMatrix[i][j]='x';
            }
            else{
                ptMatrix[i][j]=pt[k++];
            }

        }
    }
    string cipher="";
    for(int i=0;i<key.length();i++){
        int k=key[i]-'0';
        for(int j=0;j<row;j++){
            cipher+=ptMatrix[j][k];
        }
    }
    cout<<"Cipher: "<<cipher<<"\n";
}