#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
    string pt,key;
    cin>>pt;
    cin>>key;
    string cipher="";
    transform(pt.begin(),pt.end(),pt.begin(),::toupper);
    for(int i=0;i<pt.length();i++){
        cipher += key[pt[i]-'A'];
    }
    cout<<"cipher TExt: "<<cipher<<"\n";
}