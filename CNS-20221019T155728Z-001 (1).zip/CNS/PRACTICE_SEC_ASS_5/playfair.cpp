#include<iostream>
#include<bits/stdc++.h>
using namespace std;
void generateMatrixKey(string key,char keyMatrix[5][5]){
     int row=0,col=0;
     bool flag=false;
    for(int i=0;i<key.length();i++){
        if(flag&&(key[i]=='I'||key[i]=='J'))
        continue;
        if(key.find(key[i])!=string::npos){
            int pos=key.find(key[i]);
            if(pos<i)
            continue;
        }
        if(col==5){
        row++;col=0;}
    
        keyMatrix[row][col++]=key[i];  
        if(key[i]=='I' ||key[i]=='J')
        flag=true;
    }
    if(row>=4 && col==5)
    return;

    for(char c='A';c<='Z';c++){
        if(flag && (c=='I'||c=='J'))
        continue;
        if(key.find(c)!=string::npos){
             continue;
        }
        if(col==5){
        row++;col=0;}
        if(row==5)
        return;
        keyMatrix[row][col++]=c;
        if(c=='I')
        c++;
    }

}
void printKeyMatrix(char keyMatrix[5][5]){
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++)
        cout<<keyMatrix[i][j]<<' ';
        cout<<"\n";
    }
}
void findPos(char x,char y,char keyMatrix[5][5],int posx[],int posy[]){
      int cnt=2;
      bool flagx=false,flagy=false;
      if(x=='I'||x=='J')
      flagx=true;
      if(y=='I'||y=='J')
      flagy=true;
      for(int i=0;i<5&&cnt;i++){
          for(int j=0;j<5&&cnt;j++){
              if(keyMatrix[i][j]=='I'||keyMatrix[i][j]=='J'){
                  if(flagx)
                  {
                      posx[0]=i;posx[1]=j;
                      cnt--;
                      continue;

                  }
                  if(flagy)
                  {
                      posy[0]=i;posy[1]=j;
                      cnt--;
                      continue;
                  }
                  
              }
              else{
                  if(keyMatrix[i][j]==x)
                  {

                      posx[0]=i;posx[1]=j;
                      cnt--;
                  }
                  else if(keyMatrix[i][j]==y)
                  {

                      posy[0]=i;posy[1]=j;
                      cnt--;
                  }
    
                }
          }
      }
    
}
string encrypt(string pt,char keyMatrix[5][5]){
    int i=0;
    string cipher="";
    while(i<pt.length()){
        char x,y;
        if((i==pt.length()-1)||pt[i]==pt[i+1]){
            x=pt[i];y='X';
            i++;
        }
        else{
            x=pt[i];y=pt[i+1];
            i+=2;
        }
        int posx[2],posy[2];
        findPos(x,y,keyMatrix,posx,posy);
        if(posx[0]==posy[0]){
            cipher+=keyMatrix[posx[0]][(posx[1]+1)%5];
            cipher+=keyMatrix[posy[0]][(posy[1]+1)%5];
        }
        else if(posx[1]==posy[1]){
            cipher+=keyMatrix[(posx[0]+1)%5][posx[1]];
            cipher+=keyMatrix[(posy[0]+1)%5][posy[1]];
        }
        else{
            cipher+=keyMatrix[posx[0]][posy[1]];
            cipher+=keyMatrix[posy[0]][posx[1]];
        }
    }
    return cipher;
}
int main(){
     string pt,key;
     cin>>pt;
     cin>>key;
     transform(key.begin(),key.end(),key.begin(),::toupper);
     transform(pt.begin(),pt.end(),pt.begin(),::toupper);
     
     char keyMatrix[5][5];

     generateMatrixKey(key,keyMatrix);
     cout<<"key is: \n";
     printKeyMatrix(keyMatrix);

     string cipherText = encrypt(pt,keyMatrix);
     cout<<"Cipher is: "<<cipherText<<"\n";
}