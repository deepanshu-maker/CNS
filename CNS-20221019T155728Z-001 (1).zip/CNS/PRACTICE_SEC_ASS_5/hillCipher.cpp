#include<iostream>
#include<bits/stdc++.h>
using namespace std;
vector<int> multiplyMatrix(vector<int>v,vector<vector<int> >key){
    int n=v.size();
    vector<int>cipherMatrix(n,0);
    for(int i=0;i<v.size();i++){
        for(int j=0;j<n;j++){
            cipherMatrix[i]=(cipherMatrix[i]+(v[i]*key[i][j])%26)%26;
        }
    }
    return cipherMatrix;
}
int main(){
    string pt;
    cin>>pt;

        string cipher="";
    int n;
    cin>>n;
    vector<vector<int> >key(n,vector<int>(n));
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++)
        cin>>key[i][j];
    }
    for(int i=0;i<pt.length()-n+1;i+=n){
        int j=0;
        vector<int>v;
        while(j<3&&(i+j)<pt.length()){
            v.push_back(pt[i+j]-'a');
            j++;
        }
        while(j<3){
            v.push_back(23);
            j++;
        }
        vector<int> cipherVector=multiplyMatrix(v,key);
        for(int x:cipherVector){
            cipher+= char (x+'a');
        }

    }
    cout<<cipher<<"\n";
}