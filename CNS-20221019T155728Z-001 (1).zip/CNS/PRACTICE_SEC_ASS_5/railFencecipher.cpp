#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
    string pt;
    cin>>pt;
    int fence;
    cin>>fence;
    string cipher="";
    for(int i=0;i<fence;i++){
        int j=i;
        while(j<pt.length()){
            cipher+=pt[j];
            j+=fence;
        }
    }
    cout<<"cipherText: "<<cipher<<"\n";
}