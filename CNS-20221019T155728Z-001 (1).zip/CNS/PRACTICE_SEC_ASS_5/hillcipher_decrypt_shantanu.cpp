#include<bits/stdc++.h>
using namespace std;
int main()
{
  int n,m;
  cout<<"Enter the key rows";
  cin>>n;
  cout<<"Enter the key columns";
  cin>>m;
  int key[n][m];
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<m;j++)
    {
    	int x;
    	cin>>x;
    	key[i][j]=x;
    }
  }
  int det=key[0][0]*key[1][1]-key[0][1]*key[1][0];
  int det_in=1;
  for(int i=0;i<26;i++)
  {
     if((det*i)%26==1)
     {
     	det_in=i;
     	break;
     }
  }
  key[1][0]=0-key[1][0];
  key[0][1]=0-key[0][1];
  int temp=key[1][1];
  key[1][1]=key[0][0];
  key[0][0]=temp;
  for(int i=0;i<n;i++)
  {
     for(int j=0;j<m;j++)
     {
     	key[i][j]*=det_in;
     	while(key[i][j]<0)
     	{
     	    key[i][j]+=26;
     	}
     	key[i][j]%=26;
     	cout<<key[i][j]<<" ";
     }
     cout<<endl;
  }
  string data;
  cout<<"Enter the ciphertext";
  cin>>data;
  int dl=ceil(data.length()/m);
  int d[m][dl];
  int itr=0;
  for(int j=0;j<dl;j++)
  {
    for(int i=0;i<m;i++)
    {
    	if(itr<data.length())
    	{
    	   d[i][j]=data[itr++]-'a';
    	}
    	else
    	{
    	     d[i][j]=(itr++)%26;
    	}
    }
  }
  int c[n][dl];
  for(int i=0;i<n;i++)
  {
  	for(int j=0;j<dl;j++)
  	{
  		int s=0;
  		for(int k=0;k<m;k++)
  		{
  			s+=key[i][k]*d[k][j];
  		}
  		s%=26;
  		c[i][j]=s;
  	}
  }
  string plaintext;
  for(int j=0;j<dl;j++)
  {
     for(int i=0;i<m;i++)
     {
     	plaintext.push_back('a'+c[i][j]);
     }
  }
  cout<<"plaintext :- "<<plaintext<<endl;
}