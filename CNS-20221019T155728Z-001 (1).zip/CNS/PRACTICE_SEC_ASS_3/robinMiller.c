#include<gmp.h>
#include<stdio.h>
#include<time.h>
void doPower(mpz_t a,mpz_t q,mpz_t power){
    
    mpz_t i;
    mpz_init(i);
    mpz_set_ui(i,0);
    mpz_set_ui(power,1);
    for(;mpz_cmp(i,q)<0;mpz_add_ui(i,i,1)){
        mpz_mul(power,power,a);
    }

}
void robinMiller(mpz_t n,mpz_t ans){
    if(mpz_cmp_ui(n,1)==0)
    {
        mpz_set_ui(ans,0);
        return;
    }
    if(mpz_cmp_ui(n,3)<=0){
        mpz_set_ui(ans,1);
        return;
    }
    mpz_t q,k,temp;
    mpz_inits(q,k,temp,NULL);
    mpz_sub_ui(temp,n,1);
    // gmp_printf("4\n");
   
    while(1)
    { 
        mpz_t r;
        mpz_init(r);
        mpz_mod_ui(r,temp,2);
        if(mpz_cmp_ui(r,0)!=0)
        break;
        mpz_add_ui(k,k,1);
        mpz_fdiv_q_ui(temp,temp,2);
    }
    // gmp_printf("5\n");
   
    mpz_set(q,temp);

    mpz_t a;
    mpz_init(a);
    gmp_randstate_t state;
    gmp_randinit_mt(state);
    unsigned long seed;
    seed=time(NULL);
    gmp_randseed_ui(state,seed);
    mpz_t upperLimit;
    mpz_init(upperLimit);
    mpz_sub_ui(upperLimit,n,3);
    mpz_urandomm(a,state,upperLimit);
    mpz_add_ui(a,a,2);

    mpz_t power;
    mpz_init(power);
    doPower(a,q,power);
    
    mpz_t rem;
    mpz_init(rem);
    mpz_mod(rem,power,n);
    if(mpz_cmp_ui(rem,1)==0){
        mpz_set_ui(ans,1);
        return;
    }

    mpz_t i;
    mpz_init(i);
    mpz_set_ui(i,0);
    for(;mpz_cmp(i,k)<0;mpz_add_ui(i,i,1)){
        mpz_mul(power,power,power);
        mpz_mod(rem,power,n);
        mpz_t temp;
        mpz_init(temp);
        mpz_sub_ui(temp,n,1);
        if(mpz_cmp_ui(rem,-1)==0 || mpz_cmp(rem,temp)==0 ){
            mpz_set_ui(ans,1);
            return;
        }
    }
    mpz_set_ui(ans,0);
    return;



}
int main(){
   mpz_t n;
   mpz_init(n);
   gmp_printf("Enter the number\n");
   gmp_scanf("%Zd",n);

   mpz_t ans;
   mpz_init(ans);
//    gmp_printf("1\n");

   robinMiller(n,ans);
//    gmp_printf("2\n");
   
   if(mpz_cmp_ui(ans,0)==0)
   gmp_printf("number is composite\n");
   else
   gmp_printf("number is inconclusive\n");
// gmp_printf("3\n");
   
}