#include<gmp.h>
void exponentiation(mpz_t a,mpz_t x,mpz_t n,mpz_t ans){
    mpz_t temp,i;
    mpz_inits(temp,i,NULL);
    mpz_set_ui(temp,1);
    mpz_set_ui(i,0);
    for(;mpz_cmp(i,x)<0;mpz_add_ui(i,i,1)){
        mpz_mul(temp,temp,a);
        mpz_mod(temp,temp,n);
    }
    mpz_set(ans,temp);
}
int main(){
    mpz_t a,x,n;
    mpz_inits(a,x,n,NULL);
    
    gmp_printf("Enter the base\n");
    gmp_scanf("%Zd",a);

    gmp_printf("Enter the power\n");
    gmp_scanf("%Zd",x);

    gmp_printf("Enter the mod value\n");
    gmp_scanf("%Zd",n);

    mpz_t ans;
    exponentiation(a,x,n,ans);
    gmp_printf("a^x mod n is: %Zd\n",ans);
    
    
}