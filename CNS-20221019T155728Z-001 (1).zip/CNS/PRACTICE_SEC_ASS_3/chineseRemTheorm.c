#include <gmp.h>
#include <stdlib.h>
#include <stdio.h>
void findMI(mpz_t num, mpz_t n, mpz_t mi)
{

    mpz_t x1, y1, x2, y2, b;
    mpz_inits(x1, y1, x2, y2, b, NULL);
    mpz_set_ui(x1, 1);
    mpz_set_ui(y1, 0);
    mpz_set_ui(x2, 0);
    mpz_set_ui(y2, 1);
    
    mpz_t a;
    mpz_init(a);
    mpz_set(a,num);
    mpz_set(b, n);
    // gmp_printf("Enter second number 3 \n");
    mpz_t r, q;
    mpz_inits(r, q, NULL);
    while (1)
    {

        // gmp_printf("Enter second number 4\n");
        mpz_fdiv_q(q, a, b);

        // gmp_printf("Enter secon 5\n");
        mpz_mod(r, a, b);

        gmp_printf("Enter secon 5\n");

        if (mpz_cmp_ui(r, 0) == 0)
            break;

        mpz_t temp, new_x2, new_y2;
        mpz_inits(temp, new_x2, new_y2);

        mpz_mul(temp, q, x2);
        mpz_sub(new_x2, x1, temp);

        // gmp_printf("Enter second number\n");
        mpz_mul(temp, q, y2);
        mpz_sub(new_y2, y1, temp);

        mpz_set(x1, x2);
        mpz_set(y1, y2);

        mpz_set(x2, new_x2);
        mpz_set(y2, new_y2);
        mpz_set(a, b);
        mpz_set(b, r);
    }
    // gmp_printf("gcd is: %Zd\n", b);
    //   gmp_printf("a is: %Zd\n",a);
    //   gmp_printf("x2 is: %Zd\n",x2);
    //   gmp_printf("x1 is: %Zd\n",x1);
    //   gmp_printf("y1 is: %Zd\n",y1);
    //   gmp_printf("y2 is: %Zd\n",y2);

    if (mpz_cmp_ui(b, 1) != 0)
    {
        //   gmp_printf("hi");
        mpz_set_ui(mi, -1);
    }
    else
    {
        mpz_set(mi, x2);
    }
}
void CRM(mpz_t *mod, mpz_t *rem, mpz_t ans, unsigned int x)
{
    mpz_t M;
    mpz_init(M);
    mpz_set_ui(M, 1);
    for (int i = 0; i < x; i++)
        mpz_mul(M, M, mod[i]);

    mpz_t *modArr = malloc(sizeof(mpz_t) * x);
    for (int i = 0; i < x; i++)
        mpz_init(modArr[i]);

    for (int i = 0; i < x; i++)
    {
        mpz_fdiv_q(modArr[i], M, mod[i]);
    }

    mpz_t *MI_Y = malloc(sizeof(mpz_t) * x);
    for (int i = 0; i < x; i++)
        mpz_init(MI_Y[i]);
    
    for (int i = 0; i < x; i++)
    {
        findMI(modArr[i], mod[i], MI_Y[i]);
        if (mpz_cmp_ui(MI_Y[i], 0) < 0)
        {
            mpz_add(MI_Y[i], MI_Y[i], mod[i]);
        }
    }

    mpz_t sum;
    mpz_init(sum);
    mpz_set_ui(sum, 0);
    for (int i = 0; i < x; i++)
    {
        mpz_t temp;
        mpz_init(temp);
        mpz_mul(temp, modArr[i], MI_Y[i]);
        mpz_mul(temp, temp, rem[i]);
        mpz_add(sum, sum, temp);
    }
    mpz_mod(sum, sum, M);
    mpz_set(ans, sum);
}
int main()
{
    gmp_printf("Enter the numbers of element\n");
    unsigned int x;
    scanf("%u", &x);
    // mpz_t a[100];
    mpz_t *mod;
    mod = malloc(sizeof(mpz_t) * x);
    for (int i = 0; i < x; i++)
        mpz_init(mod[i]);

    gmp_printf("Enter the mod...m1...m2....\n");
    for (int i = 0; i < x; i++)
        gmp_scanf("%Zd", mod[i]);

    mpz_t *rem;
    rem = malloc(sizeof(mpz_t) * x);
    for (int i = 0; i < x; i++)
        mpz_init(rem[i]);

    gmp_printf("Enter the remainders a1...a2...a3\n");
    for (int i = 0; i < x; i++)
        gmp_scanf("%Zd", rem[i]);

    mpz_t ans;
    mpz_init(ans);
    CRM(mod, rem, ans, x);
    gmp_printf("The number is: %Zd\n", ans);
}