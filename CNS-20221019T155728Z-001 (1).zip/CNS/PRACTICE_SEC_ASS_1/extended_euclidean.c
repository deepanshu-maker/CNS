#include<gmp.h>
void extendedEuclidean(mpz_t a,mpz_t b,mpz_t x,mpz_t y){

    // gmp_printf("Enter second number 2\n");

      mpz_t x1,y1,x2,y2;
      mpz_inits(x1,y1,x2,y2,NULL);
      mpz_set_ui(x1,1);
      mpz_set_ui(y1,0);
      mpz_set_ui(x2,0);
      mpz_set_ui(y2,1);

    // gmp_printf("Enter second number 3 \n");
      mpz_t r,q;
      mpz_inits(r,q,NULL);
      while(1){

    // gmp_printf("Enter second number 4\n");
          mpz_fdiv_q(q,a,b);
          mpz_mod(r,a,b);
          if(mpz_cmp_ui(r,0)==0)
          break;

    gmp_printf("Enter second number 5\n");

          mpz_t temp,new_x2,new_y2;
          mpz_inits(temp,new_x2,new_y2);

          mpz_mul(temp,q,x2);
          mpz_sub(new_x2,x1,temp);

   // gmp_printf("Enter second number\n");
          mpz_mul(temp,q,y2);
          mpz_sub(new_y2,y1,temp);

          mpz_set(x1,x2);
          mpz_set(y1,y2);

          mpz_set(x2,new_x2);
          mpz_set(y2,new_y2);
          mpz_set(a,b);
          mpz_set(b,r);

      }
      mpz_set(x,x2);
      mpz_set(y,y2);
      
}
void main(){
    mpz_t a,b;
    mpz_inits(a,b,NULL);
    gmp_printf("Enter first number\n");
    gmp_scanf("%Zd",a);

    gmp_printf("Enter second number\n");
    gmp_scanf("%Zd",b);

    

//    gmp_printf("Enter second number 1\n");
    mpz_t x,y;
    mpz_inits(x,y,NULL);
    extendedEuclidean(a,b,x,y);

    // gmp_printf("Enter second number\n");
    gmp_printf("numbers can be represented as ax+by=1 : x: %Zd , y: %Zd\n",x,y);

}