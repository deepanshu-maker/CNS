#include<gmp.h>
void euclideanGCD(mpz_t a,mpz_t b,mpz_t gcd){
    mpz_t r;
    mpz_init(r);
    while(mpz_cmp_ui(b,0)!=0){
        mpz_mod(r,a,b);
        mpz_set(a,b);
        mpz_set(b,r);

    }
    mpz_set(gcd,a);
}
int main(){
    mpz_t a,b,gcd;
    mpz_inits(a,b,NULL);
    
    gmp_printf("Enter the first number\n");
    gmp_scanf("%Zd",a);

    gmp_printf("enter the second number\n");
    gmp_scanf("%Zd",b);
   
    euclideanGCD(a,b,gcd);

    gmp_printf("Gcd of numbers are: %Zd\n",gcd);

}